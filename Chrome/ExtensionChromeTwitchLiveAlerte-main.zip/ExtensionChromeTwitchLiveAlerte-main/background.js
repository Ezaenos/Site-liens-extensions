const userId = 54401093;
const clientId = 'na3wshqsen8ha9wsj4kj7u8xau1v';
const clientSecret = 'vhjyprzw0epqdnctyfeu2x1qpat1mb'; // Remplacez par votre secret client
let tokenInfo;

const twitchUrl = "https://www.twitch.tv/esaenos";

let isLiveOn = false;
let retryCount = 0;

function getTwitchToken(clientId, clientSecret) {
    const url = `https://id.twitch.tv/oauth2/token?client_id=${clientId}&client_secret=${clientSecret}&grant_type=client_credentials`;

    return fetch(url, {
        method: 'POST'
    }).then(response => response.json())
    .then(data => {
        // Calculez le temps d'expiration en millisecondes
        const expiresInMilliseconds = data.expires_in * 1000;
        const expirationTime = Date.now() + expiresInMilliseconds;

        return {
            token: data.access_token,
            expirationTime: expirationTime
        };
    });
}

function fetchTwitchAPI(url, headers) {
    return fetch(url, {
        method: 'GET',
        headers: headers
    }).then(response => response.json());
}

function setIcon(path) {
    chrome.action.setIcon({ path: path });
}

function cb(json) {
    if (json && json.data && json.data.length) {
        setIcon('images/live_on.png');
        isLiveOn = true;
        retryCount = 0;

        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'images/live_on.png',
            title: 'MINNIE CRAZY',
            message: 'Minnie est en stream, clique ici pour la rejoindre !'
        });
        
    } else {
        setIcon('images/live_off.png');
        isLiveOn = false;
        retryCount = 0;
    }
}

function checkTokenAndFetchAPI() {
    if (!tokenInfo || Date.now() > tokenInfo.expirationTime) {
        // Le token est expiré ou n'existe pas, obtenir un nouveau token
        getTwitchToken(clientId, clientSecret).then(newTokenInfo => {
            tokenInfo = newTokenInfo;

            let headers = {
                'Authorization': `Bearer ${tokenInfo.token}`,
                'Client-ID': clientId
            }

            const url = `https://api.twitch.tv/helix/streams?user_id=${userId}`;

            fetchTwitchAPI(url, headers).then(cb);
        });
    } else {
        // Le token est toujours valide, l'utiliser pour faire des requêtes à l'API
        let headers = {
            'Authorization': `Bearer ${tokenInfo.token}`,
            'Client-ID': clientId
        }

        const url = `https://api.twitch.tv/helix/streams?user_id=${userId}`;

        fetchTwitchAPI(url, headers).then(cb);
    }
}

// Appeler cette fonction au lieu de fetchTwitchAPI
checkTokenAndFetchAPI();

chrome.alarms.create({ periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener(() => {
    checkTokenAndFetchAPI();
});

chrome.notifications.onClicked.addListener(() => {
    chrome.tabs.create({
        url: twitchUrl
    })
});